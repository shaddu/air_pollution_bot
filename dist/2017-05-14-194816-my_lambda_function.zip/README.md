# air_pollution_bot
a bot with aws lex and lambda to check the air pollution of a city
